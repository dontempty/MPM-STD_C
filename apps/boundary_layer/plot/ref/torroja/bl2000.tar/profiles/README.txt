The files in this directory tree contain statistical data extracted from 
direct numerical simulations of fully developed ZPG Boundary Layer
flow. There are three files at three different Reynolds numbers: nominal 
Reynolds numbers based on \theta (Momentum thickness) and U_inf (U at the
infinity) are 1100, 1550 and 1970. These files contains the averaged
profiles of the boundary layer, averaged again in x in small intervals
centered at each of the three Reynolds numbers.

The algorithm used is presented in 
- M. P. Simens, J. Jimenez, S. Hoyas, Y. Mizuno
  "A high-resolution code for turbulent boundary layers"
  Journal of Computational Physics
  Volume 228, Issue 11, 20 June 2009, Pages 4218-4231 

These data are discussed in

- J. Jimenez, S. Hoyas, M. P. Simens, Y. Mizuno
  "COMPARISON OF TURBULENT BOUNDARY LAYERS AND CHANNELS FROM
  DIRECT NUMERICAL SIMULATION"
  Submitted to the Journal of Fluid mechanics

Before final publication of a paper citing these data, please check this
site for an up-to-date reference.

The files are written in plane ASCII format.

Please report any problems with the data to S. Hoyas, 
sergio@torroja.dmt.upm.es
